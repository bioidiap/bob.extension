.. vim: set fileencoding=utf-8 :
.. Andre Anjos <andre.anjos@idiap.ch>
.. Mon 13 Aug 2012 12:36:40 CEST

=====================
 Bob Example Project
=====================


Package Documentation
---------------------

.. automodule:: bob.example.project


